import sys
import csv
import numpy as np
import pysam                        
import py_kmc_api as kmc            
import bgzip
from time import time
from Bio import bgzf

BGZ_SUFFIX = ".pank"
ANN_SUFFIX = ".pana"

class KmerBitmap:
    def __init__(self, prefix, kmc=None, genome_tsv=None, anchors=None):
        self.prefix = prefix
        self.bgz_fname = prefix + BGZ_SUFFIX
        self.ann_fname = prefix + ANN_SUFFIX

        self.offsets = dict()
        self.ref_len = 0

        if kmc is None and genome_tsv is None:
            self._init_read()
        else:
            self._init_write(kmc, genome_tsv, anchors)

    def _init_read(self):
        self.write_mode = False

        with open(self.ann_fname) as self.ann:
            self.ngenomes, self.nbytes = map(int, self.ann.readline().split())
            #self._set_ngenomes(ngenomes)
            #self.ngenomes = len(self.fastas)

            self.genomes = list()

            nt_offs = 0
            for line in self.ann:
                nt_offs, genome, seq_name = line.split()[:3]
                self.offsets[seq_name] = int(nt_offs)
                if len(self.genomes) == 0 or genome != self.genomes[-1]:
                    self.genomes.append(genome)
            self.ref_len = nt_offs

        #t = time()
        #idx_in = open(self.prefix + ".panx", "rb")
        #nblocks = np.fromfile(idx_in, "uint64", 1)[0]
        #dtype = [("rstart", "uint64"), ("dstart", "uint64")]
        #blocks = np.zeros(int(nblocks)+1, dtype=dtype)
        #blocks[1:] = np.fromfile(idx_in, dtype, nblocks)
        #self.bgz_blocks = blocks.astype([("rstart", int), ("dstart", int)])


        #self.bgz = bgzf.BgzfReader(self.bgz_fname, "rb")
        self.bgz = open(self.bgz_fname, "rb")

    def query(self, name, start, end, step=1):
        byte_start = self.nbytes * (self.offsets[name] + start)
        length  = end - start

        #blk = np.searchsorted(self.bgz_blocks["dstart"], byte_start, side="right")-1
        #blk_offs = byte_start - self.bgz_blocks["dstart"][blk]
        #blk_start = self.bgz_blocks["rstart"][blk]


        #self.bgz.seek(bgzf.make_virtual_offset(blk_start, blk_offs))
        self.bgz.seek(byte_start)
        buf = self.bgz.read(length * self.nbytes)

        pac = np.frombuffer(buf, "uint8").reshape((length, self.nbytes))
        if step > 1:
            pac = pac[::step]
        ret = np.unpackbits(pac, axis=1)[:,:self.ngenomes]

        #pac = np.frombuffer(buf, "uint32")
        #ret = np.zeros((len(pac), self.ngenomes), dtype="uint8")
        #for i in range(self.ngenomes):
        #    ret[:,i] = (pac >> i) & 1

        return ret
    
    @property
    def genome_names(self):
        return list(self.genomes)


    def _init_write(self, kmc_file, genome_tsv, anchors):
        self.write_mode = True
        #self.bgz = bgzip.BGZipWriter(open(self.bgz_fname, "wb"))
        self.bgz = open(self.bgz_fname, "wb")
        self.ann = open(self.ann_fname, "w")

        self.kmc_db = kmc.KMCFile()        
        self.kmc_db.OpenForRA(kmc_file)

        self.genomes = list()
        self.fastas = dict()
        with open(genome_tsv) as genome_file:
            genomes_in = csv.reader(genome_file, delimiter="\t")
            for name, fasta in genomes_in:
                self.genomes.append(name)
                self.fastas[name] = fasta

        self.ngenomes = len(self.fastas)
        self.nbytes = int(np.ceil(self.ngenomes / 8))

        self.ann.write(f"{self.ngenomes}\t{self.nbytes}\n")

        for name, fasta in self.fastas.items():
            if anchors is None or name in anchors:
                self._load_fasta(name, fasta)

    #pac_out = open(f"{out_prefix}.pank", "wb")
    #ann_out = open(f"{out_prefix}.pana", "w")
    #pac_bgz = bgzip.BGZipWriter(pac_out)

    def _load_fasta(self, name, fname):

        with pysam.FastaFile(fname) as fasta:
            vec = kmc.CountVec()
            t = time()
            for seq_name in fasta.references:       
                seq = fasta.fetch(seq_name)#, 0, 10000000) 

                self.kmc_db.GetCountersForRead(seq, vec)

                arr = np.array(vec, dtype="uint32")
                arr = arr.view("uint8").reshape((len(arr),4))
                if self.nbytes < 4:
                    arr = arr[:,:self.nbytes]

                self.bgz.write(arr.tobytes())

                self.ann.write(f"{self.ref_len}\t{name}\t{seq_name}\n")
                self.ref_len += len(arr)

                print(f"Anchored {seq_name}", time()-t)
                t = time()

    def close(self):
        self.ann.close()
        self.bgz.close()

        #if self.write_mode:
        #    self.kmc_db.close()
